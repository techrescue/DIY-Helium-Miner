# Chain Variable Transaction 14

## Changes

This was a mistaken resubmission of variable 13.  It is essentially a noop.

## Acceptance block

164512

## Acceptance block time

Mon 06 Jan 2020 09:22:14 PM UTC
